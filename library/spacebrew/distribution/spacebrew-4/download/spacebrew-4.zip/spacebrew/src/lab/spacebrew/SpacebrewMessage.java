package spacebrew;

class SpacebrewMessage {
  // to-do: this is weird!
  public String name, type, _default;
  public int       intValue;
  public String    stringValue;
  public boolean   boolValue;
}